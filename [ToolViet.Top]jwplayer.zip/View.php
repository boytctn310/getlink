<?php
$url=$_GET['url'];
header("Refresh:5");
?>
<title>Tăng view cho <?php echo $url ?></title>
Đang chạy view nà...5s/ Reset 1 lần ,link : <b><?php echo $url ?></b>,1 lần tầm 30 view (nhớ fake ip)
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>
<iframe style="display:none" src="<?php echo $url ?>"></iframe>